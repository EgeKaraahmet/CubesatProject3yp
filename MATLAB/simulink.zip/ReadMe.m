%% Read me 

%% This folder presents the following codes: 
% 1) validation 
% 2) SatSim_ARES
% All others are built in function to in validation. 

% In validation, please run initialisation first, to get the constant value
% for SatSim_ARES to work. 

%% Problems 
% The persistent problem is in , in which the clock is not
% updating at all. SatSim_ARES.slx